char* player_race_display(int cap);
char* enemy_race_display(int cap);
int * player_stats_gen(int i);
int * enemy_stats_gen(int i);
void stats_deploy();