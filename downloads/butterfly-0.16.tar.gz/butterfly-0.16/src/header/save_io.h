int * save_reader();
void save_writer(int line, signed int state);
void save_generate();
void save_exists();