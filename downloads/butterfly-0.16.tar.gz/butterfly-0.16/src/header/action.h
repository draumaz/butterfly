int items(int x, int y);
void attack(int x, int y, int way);
int spare(int x, int y);